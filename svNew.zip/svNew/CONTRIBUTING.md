Contributing to Bitcoin SV
===========================

Thank you for your interest.

At this stage in the development of Bitcoin SV we are not
accepting contributions to the project. We expect to change
this policy soon.
