
Debian
====================
This directory contains files used to package bitcoind
for Debian-based Linux systems. If you compile bitcoind yourself, there are some useful files here.
